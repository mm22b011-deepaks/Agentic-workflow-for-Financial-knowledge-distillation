"""Index-level aggregation."""
